
import streamlit as st
from Demo_MultiApp import MultiApp
from apps import teoria, rlc_serie, rlc_paralelo, comparador, resumen_parametros

app = MultiApp()
app.add_app("📘 Teoría", teoria.app)
app.add_app("🔁 RLC Serie", rlc_serie.app)
app.add_app("🔁 RLC Paralelo", rlc_paralelo.app)
app.add_app("📊 Comparador de Respuestas", comparador.app)
app.add_app("📈 Parámetros Característicos", resumen_parametros.app)
app.run()
