
import streamlit as st

def app():
    st.title("📘 Teoría de Sistemas Amortiguados")

    st.markdown("""
    En un sistema de segundo orden como los circuitos RLC, el tipo de amortiguamiento se clasifica según el valor del factor de amortiguamiento \(\zeta\):

    - **Subamortiguado**: \( \zeta < 1 \)
    - **Amortiguamiento crítico**: \( \zeta = 1 \)
    - **Sobreamortiguado**: \( \zeta > 1 \)

    Donde:

    \[
    \zeta = \frac{R}{2} \sqrt{\frac{C}{L}}, \quad
    \omega_n = \frac{1}{\sqrt{LC}}, \quad
    \omega_d = \omega_n \sqrt{1 - \zeta^2}
    \]

    También se puede representar en forma canónica o como péndulo elástico.
    """)
