
import streamlit as st
import numpy as np
import matplotlib.pyplot as plt
from control import TransferFunction, step_response, impulse_response, bode, pzmap

def app():
    st.title("🔁 Simulación RLC Paralelo")

    R = st.slider("Resistencia R [Ω]", 1.0, 100.0, 10.0)
    L = st.slider("Inductancia L [H]", 0.001, 1.0, 0.1)
    C = st.slider("Capacitancia C [F]", 1e-6, 0.01, 100e-6)

    zeta = 1 / (2 * R) * np.sqrt(L / C)
    wn = 1 / np.sqrt(L * C)
    wd = wn * np.sqrt(1 - zeta**2) if zeta < 1 else 0

    st.markdown(f"**ζ (factor de amortiguamiento):** {zeta:.3f}")
    st.markdown(f"**ωₙ (frecuencia natural):** {wn:.2f} rad/s")
    st.markdown(f"**ω_d (frecuencia amortiguada):** {wd:.2f} rad/s")

    num = [1, 0]
    den = [L*C, L/R + C, 1]
    sistema = TransferFunction(num, den)

    # Respuestas
    t, y = step_response(sistema)
    ti, yi = impulse_response(sistema)

    fig1, ax1 = plt.subplots()
    ax1.plot(t, y, label="Escalón")
    ax1.plot(ti, yi, label="Impulso")
    ax1.set_title("Respuesta al Escalón e Impulso")
    ax1.set_xlabel("Tiempo [s]")
    ax1.grid(True)
    ax1.legend()
    st.pyplot(fig1)

    # Diagrama de Bode
    mag, phase, omega = bode(sistema, Plot=False)
    fig2, (ax_mag, ax_phase) = plt.subplots(2, 1)
    ax_mag.semilogx(omega, 20 * np.log10(mag))
    ax_mag.set_title("Diagrama de Bode - Magnitud")
    ax_mag.set_ylabel("dB")
    ax_mag.grid(True)

    ax_phase.semilogx(omega, np.degrees(phase))
    ax_phase.set_title("Diagrama de Bode - Fase")
    ax_phase.set_xlabel("Frecuencia [rad/s]")
    ax_phase.set_ylabel("Grados")
    ax_phase.grid(True)

    st.pyplot(fig2)

    # Diagrama de polos y ceros
    fig3, ax3 = plt.subplots()
    pzmap(sistema, Plot=True, ax=ax3)
    st.pyplot(fig3)
