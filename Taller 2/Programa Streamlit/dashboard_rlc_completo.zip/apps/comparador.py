
import streamlit as st
import numpy as np
import matplotlib.pyplot as plt
from control import TransferFunction, step_response

def get_system(tipo, R, L, C):
    if tipo == "Serie":
        num = [1]
        den = [L*C, R*C, 1]
    else:  # Paralelo
        num = [1, 0]
        den = [L*C, L/R + C, 1]
    return TransferFunction(num, den)

def app():
    st.title("📊 Comparador de Respuestas")

    tipo_1 = st.selectbox("Tipo de circuito A", ["Serie", "Paralelo"], index=0)
    tipo_2 = st.selectbox("Tipo de circuito B", ["Serie", "Paralelo"], index=1)
    R = st.slider("R [Ω]", 1.0, 100.0, 10.0)
    L = st.slider("L [H]", 0.001, 1.0, 0.1)
    C = st.slider("C [F]", 1e-6, 0.01, 100e-6)

    sys1 = get_system(tipo_1, R, L, C)
    sys2 = get_system(tipo_2, R, L, C)

    t, y1 = step_response(sys1)
    _, y2 = step_response(sys2)

    fig, ax = plt.subplots()
    ax.plot(t, y1, label=f"{tipo_1}")
    ax.plot(t, y2, label=f"{tipo_2}")
    ax.set_title("Comparación de Respuestas al Escalón")
    ax.set_xlabel("Tiempo [s]")
    ax.grid(True)
    ax.legend()
    st.pyplot(fig)
