
import streamlit as st
import numpy as np
from control import TransferFunction, step_response

def calcular_parametros(t, y):
    y_final = y[-1]
    y_max = max(y)
    sobreimpulso = ((y_max - y_final) / y_final) * 100
    tiempo_max = t[np.argmax(y)]
    settling_idx = np.where(np.abs(y - y_final) < 0.02 * y_final)[0]
    tiempo_establecimiento = t[settling_idx[0]] if len(settling_idx) > 0 else None
    return sobreimpulso, tiempo_max, tiempo_establecimiento

def app():
    st.title("📈 Parámetros Característicos del Sistema")

    tipo = st.radio("Tipo de circuito", ["Serie", "Paralelo"])
    R = st.slider("R [Ω]", 1.0, 100.0, 10.0)
    L = st.slider("L [H]", 0.001, 1.0, 0.1)
    C = st.slider("C [F]", 1e-6, 0.01, 100e-6)

    if tipo == "Serie":
        num = [1]
        den = [L*C, R*C, 1]
    else:
        num = [1, 0]
        den = [L*C, L/R + C, 1]

    sistema = TransferFunction(num, den)
    t, y = step_response(sistema)

    sobreimpulso, tiempo_max, tiempo_est = calcular_parametros(t, y)

    st.markdown(f"**Sobreimpulso [%]:** {sobreimpulso:.2f}")
    st.markdown(f"**Tiempo al pico [s]:** {tiempo_max:.4f}")
    st.markdown(f"**Tiempo de establecimiento [s]:** {tiempo_est:.4f}" if tiempo_est else "No se estabiliza claramente")
