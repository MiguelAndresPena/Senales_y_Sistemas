{
  "nbformat": 4,
  "nbformat_minor": 0,
  "metadata": {
    "colab": {
      "provenance": [],
      "include_colab_link": true
    },
    "kernelspec": {
      "name": "python3",
      "display_name": "Python 3"
    },
    "language_info": {
      "name": "python"
    }
  },
  "cells": [
    {
      "cell_type": "markdown",
      "metadata": {
        "id": "view-in-github",
        "colab_type": "text"
      },
      "source": [
        "<a href=\"https://colab.research.google.com/github/amalvarezme/SenalesSistemas/blob/master/Dashboards/Demo_MultiApp_NoNgrok.ipynb\" target=\"_parent\"><img src=\"https://colab.research.google.com/assets/colab-badge.svg\" alt=\"Open In Colab\"/></a>"
      ]
    },
    {
      "cell_type": "markdown",
      "source": [
        "# **Introducción a Streamlit**\n",
        "\n",
        "**Elaborado por:** Juan José Cardona H. juacardonahe@unal.edu.co\n",
        "\n",
        "**Revisado:** Andrés Marino Álvarez Meza amalvarezme@unal.edu.co\n",
        "\n",
        "**Universidad Nacional de Colombia - Sede Manizales**\n",
        "\n",
        "\n",
        "![streamlit.png](data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAASYAAAEICAYAAADyYlmcAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsMAAA7DAcdvqGQAADx5SURBVHhe7Z13lFVFtv9/f7z13ry1fjPPQGronNPtHOhuOt3O0IAoiIKomEaFMWcBEZQBBMxjGEfHjApiDiiCEbNizs+cR0cFlRHYb3933eob+nSChq7u2bXWZ93bt8+pc06dqu/ZtWtXnf+XlpZLiqIoLqHCpCiKc6gwKYriHCpMiqI4hwqToijOocKkKIpzqDApiuIcKkyKojiHCpOiKM6hwqQoinOoMCmK4hwqTIqiOIcKk6IozqHCpCiKc6gwKYriHCpMiqI4hwqToijOocKkKIpzqDApiuIcKkyKojiHCpOiKM6hwqQoinOoMCmK4hwqTIqiOIcKk6IozqHCpCiKc6gwKYriHCpMiqI4hwqToijOocKkKIpzqDApiuIcKkyKojiHCpOiKM6hwqQoinOoMCmK4hwqTIqiOIcKk6IozqHCpCiKc6gwKYriHCpMiqI4hwqToijOocKkKIpzqDApiuIcKkyKojiHCpOiKM6hwqQoinOoMCmK4hwqTIqiOIcKk6IozqHCpCiKc6gwKYriHCpMiqI4hwqToijOocKkKIpzqDApiuIcKkyKojiHCpOiKM6hwqQoinOoMCmK4hwqTIqiOIcKk6IozqHCpCiKc6gwKYriHCpMiqI4hwqToijOocKkKIpzqDApiuIcKkyKojiHCpOiKM6hwqQoinOoMCmK4hwqTIqiOIcKk6IozqHCpCiKc6gwKYriHCpMSi+Qx+S3/Z2Oz/RcSmXCt1OU7qHCpOwQ6an8mZ7DIpQngpSK35gUFqV0Eaz2+yhKV6gwKdsNLKJUiA8LU1xKNg1PyaFE/p6Wkc3/zzf/89hPUbpChUnZboyFBFHyUUt2EU3LK6Hs1GxKZEFKl66dr90+itIdVJiU7QZdtejkXBqdnU+P1DfRi40tdHZpBcUlZVMy/EvqY1K2ExUmpYfAGoJPKYcS+O9stpZuqK6j9f4GerSmjh5ngZqUW8TduizxO3nnoSido8Kk9AgIUmqGjz/zKTopi2aVVND6hiZaV9VAa2pr6Ym6OlrBApXP4pWQmuOZh6J0hQqT0mPS2RKKTvbR+OwCWlvXTGtr6+nhWn8bz/qbaUFZJcXxNike+ytKV6gwuQ5GufgTw/ApsFYCfwfjhPD3rrVMElO5C5eaTTcFunBraiBIdfRIDQSKP/019AR36ab4SmhECkbo0KXbdedo46cknipA6HfFfVSY+gHpLEbJLAbDEzNpWFImxaXmB4QJo14YrueulTR+E0vklUdvAHFM5nOJTcqmOaWj6Jk6dN/8TF0ENfSkv55W1jRSIXfnElLNOe58cQiKNI6FWKoU/juRzyExJYeS0rJVoPoJKkxOAwuJLZS0fCpI9dGVlXV0UYWfSvj7UBYpOJ/T0lmkIFTS+LlRBqyFnUOexCpN9BXRY/UNtI4tpUhRgtW0pgafdfR0XRMtGFlNcUlZlMTnCae5d769Ba6fxVpEO4/i+e9kttj8WQV0QEEFVWbks8Dv7HNQegMVJtcRC8VHk3KKiSbuTbTXOPqoZSzNL62gnBQfDeFGL3FDsJqkQXrk0UvA6shLyaXlbCU9xV24hwNdtzBx4t9W+833dSxOT9Q30gF87tHJGKXzzrc3geWYxOeZkJJFFZn5dHhBGc0tqaLzRlbSlPwyiucy89pPcQsVJufJE+HJ5yf9u82jiVrHMWNZoPaiN5pb6fTCMsri7t2Q5GxK4IaProq1THp3uD6PYvg46MI9W9cofiWIUJgoMXB+4xMWE0Tridp6uoO3K2WrLj4FVp3Jy/sY3aN9d8xcL3xf8alZVMqW0SG55XRWSSXNK6mgOcUVdDZ/r8ss0pHCfoIKk+PAAoBvZ1hiFl1YVkE0fgLRGBam1laisSxSe02gl5ua6Di2DFJYnIYm+ygZ+1jrRJzlEAJ89rRRGgGBwz06KYcmZBfRuvomWhciRJ1hrKl6epq7fYtG+qVLlyxiifML+MfaHbN7IOJcumz8PZG7sfHcZSviv6fmldFstpDmsYCeVTSKZhdBlMrphMIKymThSo7IR3ETFSbHyeDGBJEZkeqjlowC2tQ6nkWJLafRY2lb6xgWKWYsi9Ve4+kZFo1Dc4tYRHw0jEVKGj+LiozkiRDkUzp8UR7H8SaPMtJ8bGX4KIuF4Ga2fJ7yt7eSOgJWEz7hi3qSxWlKLnfpWJzSJA4K14X5dF7H7QyImnHyJ/F1xbEFlMu/7ZtXSmeWjKIFxVV0FltIs4rZYipikWLml1bSRF8xW1M7JobKrkOFyWGM1WMsHoQKjGCr5cHaRraaxtG2MWwxCWP4e8CCGgcLai9a46+jiVmFYmUNT0Y+hYxxpPd0VAojW7GJOTSfG/36BoQGtBegjoAwPVJbI5bT4/4GuqO6nopY6GJZbDPgsOdra7Psugl8aYiNSmALycefe+eU0OlF5bSAu2wQpDn8fVbxKJpTWCmfRqSqqCQDgwjeeSruocLkMMaqyBErJ5Ub1pDkLJqZX0I0YW9jKcFqYnESy4m/b4U4QaxYuLYwK1kIWrLyJMxgRAqslB525fj4I5JzaF9fET1e32xG4XogTIZ6Fijs55dRusVlVRTPQoewA2O9dN+CQTcsga8ji62kcb5COoW7aeewYM7lLpuIEf9tKGdLqZw/R7GgVtFhBSMpia2llF71uSk7ExWmfoBYFQye+DlsKXzY0mIc4CFWU9v30QFEoPaiTSxQN1fVUFNGHltQmRSbgjyND8p7vSQjFun8/zi2aOB0X8EC9yRG4TxjlroCwsSfLExr+e+nuLs5LbeEBS9Trqm9MJm/rSjjb1ht8CGlsaXVkl1CJxYGBImtIfiQOmMeC1NTVj7FykoHKkz9BRWm/gQ/8YcmZtOl5ZUiOuIEbxMnD0Sg0L0bR/9sHUdXV9SSPwMxUNkUB3+LCEM4diQvJa2A4pMyaUFpFa1na+khFpW11ZGi01P89IS/nu7iz9IM4x+K7FrC72RGFX2UzFYi/EKpLEgN2UV0TGE5zS8dRfMCPiRrIXkJEoBwnVxURlmcbxK6jSJMKk79ARWmfgQaMbpkY7MK6Ndx41l00IWLEKNIxFHO2yHMYK8J9A1bWhePHEWlnNeQRB83/PBjwJeVIcfJpkm5xfQEd7/W1daaETbpxm2P1WRAHrC60KU7n7t0CclYHiVSKHIoiQUJw/opKTlUm1lER7MgzSut4G6ZEaPZMtrGXbdiOLfbC5Jlfkkl7ZdTzNYWyg5d4tDjKC6jwtTPwEhUIls8EAwaz+LUlTAxcI4bZzkEij8nTKBPeL8FEqSZHQjS5PzZgrJduDxmZXUDPcldMSNGFm/R6S7o1q3lfB5vaKbpLBojkrPkuozllCexSAiQrM7MpyPzy2huaSWdU1wpgjRLnNssOm3WkgkHCMX8Hvgf71eWUSj+paB12EM/m9InqDD1K9i64AY2jIXk1MIyGYHrjjB5bgMf1fgJ9E7zGDqtaCSlc56DkjHNJY+7cD46d2QVPcPiByvJxCP1DuKnqmFh8jfQnbWNVJqOUTrMY8OcNh+VpRfQISxICIg8p7hKRCZUdPAJgQL29yBGqObw9ZxdUkVHFZRTKpz+nDfCEnoemqD0FSpM/QxYFrEsHiX8+UULLKAu/EydwvuP5U/u4m1obKFjWBCiEzJo7+wCeryuhbtwO24hRfJwwBkO1tc30tKyaopNzKL8jDw6IL+EZpeYLtjZVmg8BagzzD7wRbVkF+oUlH6KClO/AxZAPg3nxnzjKH/ACR4pON1HungQN/isxu9N6/0Qjnp6jK2aB2pqxentJTDbixEmM9EX4QePslU2h8XoxKJyOpetnLksLrNYXGT4vwsfkhdzCjFaV0mncn4+ti6TPMtQcR0Vpn6EDKGztQSrKYotgSm+YvptHAuTjV/aLsbSNomHYusJIEiTrahvmkbT87UNtLq6lh5kAUF3Tob9I4Sm51grzESQy/QWFsNFbOUgUFLij/i76ba19yF1h3PY4to/byQlIsQgogyV/oEKUz8lCf6m5Cx6ob5J5swZB3dAXDwFyJttbC1Zx3gwmpzB78wXLFDP+OvoQRao1dUQFSMoj/RiN28dC9OtlX6aXVhOZ4pj2wRLwnLyEp7OEFErGUUVGfmyGoJX2Snuo8LUjxmalMXdlnLxEYnVNJqtnVBx6Q1ax9BWFqjPG0dzNw8CVUMP1WCaib9XLCjrWH+8tpGuKKui01mcjDCVSXfOS3w642zuFs4oLKPU1CxKgXgL3uWnuIsKUz8GAYqjuHv3rZ0rh3glL3HZAWS6C2KhWJx+Yz5qaqanaurpgWoWqR20miR0gIE4rfX7ucvYSAtZaE+F1cSc5SE8XYEpKK1weqeaFTNNGILS31Bh6sfA3zQ8MYOWV/mJxmE5lJ0gTAHM3xDAcfQrf/+gqYkeh4Ocu3g74iDHPDoI1MP+WnrU30AruUs3p6Ccu3GIXera+W1ilsx3RHqfxvvlc9lgDSuzoqd25/ojKkz9nKiUbJqWU0RbA8IU5ifqJbaFOtclJooFcOw4+oWtqXcbGmV0DRYUBMoKDUSnp3PrHmHW+U2X7rRCDPujWweHeHtBsthuH74jzODA/BJKTjbTT+yKCl7lpriNClM/B07wpBQfvdTYLNZMqKDsdCBYfMyfWKjeqm+ktdWRFlTPu3qP+OtpdU2DdOnOKDTCEylGYbCVZD8RlImIcaz1bZeL8SozxX1UmPozgW7KkMQsOpcbpjjBvQRkZwHrCUCgxo6lH/n7a3UQqJpAiEH3F5ULBV262ypraXZhGZ3ZhTDBojqLrauz+fqP5c+01BxKlEXxNLCyP6PC1M+RSHA4wTPy6LtW+IBMJLh0v0K7YL1F6PQWK0yj+ZhtAjWOvm9ppQ0sLg+JQAUmADPdG8UzwZcQpyvKMUrXhZ8pMHKHZVAm5JRKpLdZncB05bzKTHEfFaZ+DEQJPpSU9HyKSsygVdyVQiS4dViH+YZ2JSKQ4+nb5tH0kt8vAvUARImBH0k+2aLqrKu3jgVqNX+iS3dmYWVAhMLnyInTm/9G7BKc5SUsREks0joS1/9RYerXmPWvsUzJsGQfTc8rCUxRgQUDRzh8TsaC2lWYZX7H8PFH8984/nj6sqWZnmeBegA+KBaltdXGKnqktrZTK+pRfz2tqPKzCJVztw7O8KAoWc7k39CNPSQfq1RqpPdAQYWpn4PVHTF7Hi/FzEjOoTcbWRDGjWNrqSVMMHYZoS9JECBUiEwfR180tdDTbCXdX4MuHvxPnfugYF2hS/dXGaXDWt7hI3SzGDjHMQWlLrtA1pZSa2lgoMLUjzFD4TmyOD8c4UOTsmnpyEpZDiUYfwRxiBCPnQymssgcPIF/gw9KBGosbWE+bmymp1igTBS5EaGOllbBcrwP1TbQ4pIKOoPFKVSYAFazPJ7FKZPLAK8D9yonpf+hwjRQYGGKSfFRc0YubRyL1S1HizB4CUffYgRqM39+0NhCT0gMlBEomSgcZkX5zSoEdfV0OwIvZZQOVpJZOA5geZN9cksogbuyGrM0cFBhGkDAcopJyqL7uXHL6pZ9YC11xTYWzK3ig+K/uYv3C4vUuw3N9Fh1HQtUNa2urTWCxML0MKwpBhOGH/U30lUjq7lLBwd4pbwzTtZsKh5lXs2Umi/dWq9yUfofKkwDCPhXorg7d1xBqYlpGt1HfqZOYYsJk42le8cCBZEa20qb+PubDU20rtpPq6sYCJOIFJzl6NL5uUvXSOexGJ0mgoRuXCUdgTcQs6WYgpd5RpSH0n9RYRpgwAFcyA3142Y0+F0cCd4tjCCJ1RT4zfjCGLagfhw9hl6rb6A11bUyimeiyNG9q5HlUVZxl+4sOMK5OzevpJKasoskdkleGa6R3gMGFaYBBCyGFO7WYDmUK8trxAneLiDSfu9jEGPVPs4KFhR/skB9x+f6ah0LVBVioBCk6Q+M0tXTVeXVMiJ3EltNeBsvXoTpVR5K/0WFaaCRjlcv5cgrnn6RVzxFNn7XQTcPAoWwh7H0XctoehHz59h6wjQXOMcx1eXCslE0KadEXhXuWQ5Kv0aFaQBh3gKSL+9qi01Op8f9zQEnuJcAuEkwBor/loXvMIrXSt82t0iQJkIM1tY20d21DVSWkcddVw0RGIioMA0wbGzT8ORcmpJTTD+jOzc+4Gtq15WDvyfyt3B29rSWYLyV/duIkqxDLucbEKlAbNR3Lc30blMjzS6pEmtJYriUAYcK00Cjbcg8n0YkZtIhucW0oanZrNeEFxdApGBFAXT15OUDgBv/2BBrRfw9+M6CIJN0gRGPHtEmbMgL01QixTBwPAhPa+BccE5ybjhPnDPg73uNo5/487LyGkpKzqYkfbPugEWFaUCTx5ZTFmUl59C+2QV0fEEJnVVcQctGVtENlbX0YG09vVjfSG83NtNH3FX6uqWV/tk6nn5mQdhqxcsKg4gaxCFEKEQ4QrYJRbYHof/H/iw6si8L5fgJtHn8WNo4dqwsD/xJy2h6r6mJXudzeoK7ayuq/fSXimpaUFwuqwzMYJGtT2fBTfZRYno2i3C+XKP3tSv9GRWmAU8+xaXnUQw35qFsZQzm7g/e5BvL1lQik86/5yLEIM1HFRl51JRZQBOyCuhAXyEdl1dKp+WX0mwEMyJuqKSCFo2soAvLq+jKihq6hvn7qNowrmHBE0bV0N/4/5eydXNeWSXNL62guSXlNLe4jM4oKKUTOd/DcgtZMAtpXGYh1Wbky+oAeXwumVhTic81js8P78/DeQ9L8Qkx/D+8ZAAjkKkiTF7XrPR3VJgGNFh9AIGHZhUCdPPSU/GZL0vPJvPfiYC3xaqP8SxasYKPolJyaCjEgIUrisHnEBaIoYnZFMWMSMqkGBaOaP4eSkwCg8/A9xEJWSyE2bIv8gDIF+/FwzFi+Hhx/L94/h7P54bJyFivO4nPF058u4KCCZ7EuQMbs6RLnAxUVJgGOtKIPX5n4Cjf3vllGAHsLl77d0z78w2epxEq8xvW89YRuYGKCpOiKM6hwqQoinOoMCmK4hwqTIqiOIcKk6IozqHCpCiKc6gwKYriHCpMiqI4hwqToijOocKkKIpzqDApiuIcKkyKojiHCpOiKM6hwqQoinOoMClKv8Is+9L++8CiXwpTamoOk0vJyTlMNqUk+wK/6fo8ysBmxIhkGjIkRhg+PIlSUrjOb+eaWi7TD4QJy6fmyzKww4cn0rCh8RQVlUCxsSn8ew5lZOTxzcmmEdH8v2FxQnR0MguWL7CvV56K0nekp+dRKgvK8OEJUpfBsGEJFD0iyXN7kJrqo+EjEmjixMn0l8uuoGuuvpYOPeRwaQdJiVmc58Ba/9x5YYqJSaVBg6Mpx1dE+06aQosWLaYVK1bQww+voRdffIlefnkDPffc83T//Q/QzTffQrNmz6WxY/dmYcqiwYNjKDEhUyqCV96K0hekpPjIl11EU6ceRNOmTadpB0yngw48lPbZZ7L8P9zyN9+HR8XTWWfNoy1btlBouvbv11F8fCrniW0HzoPYSWGCkCQkZLCwRFNNbQNdeunl9N5779PWrVsDt6PztHnzZhGrOXPmUVZWgQgUKgPWvvY6Xudgn1C8tlGU7hMbm0pVVX765ZdfAjXWpDfeeFMsI7gn2rbnbhoezv7aZvr1182y3b/+9S/GfEeaMeNYimKLK/QY3oTWX7frsnPCBFFC3zktzUcXX3wJ/fjjj4HiJxGmf/3rt8CN8ea3336jbdu2BfYgevfd9/jGHUNDuYuX0GY94SnUkT/K3LD0DOOzwg1H93FoAHQnB2KfXtl1QJgqR/lp48ZNUketFfTaa69RWmp2uDBxfRwyJJaOO+4k2Qb1O7S+I11//c3ic/Ku0znSzYuNS+E2ECvtwH4mJWU725twSphQSGj85eXV9NJLL0uhI4XeiK1bw03Z0LRt2xa+cZt5O2BEyqYbbriZEhPTuVKk8XEKPI9vMDcKFlY2m9uHHfpHOuqomXTkkTPo6KP/RAcccDALU3bA3Hb7qaO4iRWmH3/8SeqmFZhXXnnFQ5hyadiweDqQu3pIqP+h7QHp/PMvoiFDIUzhx7EkJmZR69jxNGPmMVKPwVFH/YnKRlZTUmKm5z59jTPCBFGKikpkE7eePv74Yynw0KeDTbCGvv76a3r++RfpwQcfonvuuY8ef+wJ7uq9F2Ya4ylkBGpzWxfwvvsfEHFKSMjiY6I/3pHVlEtxcek0ciSeaj/Lvja98867LEpZ7SqPonSXngoTBnKSU7LomWeele1C0xdffEGjKmspLj4tbJ82UnNpCFtIN9+8PLBHMOGhG8Wi57lfH+OMMMXHp4tD8K233pZCM4K0mQXG3LTv/vE9XX31tTR58lQqLi7nm5Ulo28Y2UhISKOs7AKqq2+mU0+bRevXPyP7IFlh27LFWE/XXn8DC2A8W0SddecgTBlUWuqX4yIFze3XKZUriVSedIz8ee+vKB3RU2GChR8bl0rFJWW0YuVK+v7772nTpp9pzZpHqLllrLgXOuySsTANHRrL3b0b5Biox9bVMf2Qw2RE0HO/PsYZYRrGhXfddabwrKVkxeSOO+5i66WSBg0aLgUZxyKGp4jELvG++ExKyqKYmBQZwYuNTaKZM48VywrJipO1nA4/4mgxjzvzFRlhqqVvv/1O9rGV59VXX2Vhal95FKW79FSYAIQnLi6Nho+Io7LyKqqurpd6PiI6qWNRYhDvB5/SddddL8cw7co8ZKdPV2HqFAhKc1Mr/frrr6LmKDzrH7rqqqtp8KARcgOMkHTu18FNSmbh2H23odTYMJq+/PIryQd52grw/HMvspBldCouKkzKzmJ7hMmChzAECnl0Z6RZhWkHGDo0hi655C9SWEZAzFDos888R9ExidzNyxBz1mvfjoBA7b57FB35xxliKcH6Qt74vnXrNpowYRKN6CSgzQVhStfRvwHJjghTT1Fh2k6g+skpmfTCCy9KYZmCM0P+hx92FHfNRgRM1c6fDEGC2yEiPHpEAj311HrJG1bYlt/MTVmyZBkN4e5j+L5BIEwlJTUsTP+Q7UOFKYUrznZVHq4knr+HgOk1cLxj6gHCJvCJmK7OzPX25JnuLZ8jfHdoCLExqZIvurxmRNFs137fHcXkCR8ejoVjyvEZPOkRwY973n6/nQPOA2EiGI2N4XOIj0/brnuHMsPoFvKRa+FPXEuwLLvPjgsTytji9f8gIkxcz6+9tr0wHXzwoRJx7rVfX9PnwoRKU1BYRp9//oUUlr1JEITi4gppWF77dZdBg6LpnHP+LHmGprvuvpuGRcXKjbPbQgTgewK77TaMsrIK6ZtvvpXt7Xm9vGGDWHiDBsXwdmYKjN0HgXCRAoK/0TjathuKbROkwaZnmG0RZwK/GYZ8k5IyqaLCT6NHT6DW1knU0jxehnXNFBuvRmB+s+KN8hw6NE4GBRCLVcJl6K9tojp/M5WVVVNmZj43jGQaPCSGG2pa2PXvCDh+MguOmcsVKwKQxccaWVpJfr85/ihujDk5xXKNuFY4bdEIg9Mpum7kOA6EOliWBoiELfv0tHw+Ph8D55GQRnl5xVRT00B19S00sqxSBi2wD4TfCIu9ZxHHT0e3KVVihPDp8xVRZaVf8oGPJze3iAUqhYYMjg0+PHgfk0/H17I9wpSRkS+zGOz1WiD2GSi/wEBMegbaVEj5cF343e9+T3+76ho5hhEm42vdb/IU+u//3oO3xZSYkHxlcKhvY5z6XJgw16eeb/SmTRu5qBBAaW7SW2+9JTcZQWBe+3WXxMRsbhC1dNxxJ9IxxxwvnHDCyTRx3/0pkRsIrBhUTlht559/Id1++ypaseJ2uvWW2+i+e+/n89okTxicF7qB//jHd7LNbbeulO0st99+B51++izxl4UeP54FqKqqgW67bQWtXGnyvv32O+moGcfK/D7zRIuj0pGj6LzFSyViHaMu6M7+9htXIrbwbrp5OVeYOM7Pq7LntTXWIUOiqaiwlI4//kRatepOGUH86suv6KeffqJNGzfyuf9Dwh1WP/QwnXvuAi73Jm6c8dxdTglUwp5XROwHCwjnl5iYQftO2o8uuugSWrv2UXrn7XdZ2L/h42+kjXz87//5Pf3v/34oo6Z//evfaMrUaXx/TSMyAtn18WNikumAA6dLeaMsV640Zb/3PpNZaFPkXsISLi0dxQ+kBfTYY4/Rx598Qj/+9KPUsW+//ZZee/V1uvHG5bTvvlNYSOEq4IdEyPXjO+odLI3KylqaN+8cWvPwI/TBB/9L//znP2VE7IcffqAPP/xQRsZmz55LhYUjZXtzHZ3PW9seYYLbYcr+B9Htq1CHTN1bteoOmjHzeIqJTuVtTN2I4YfOlKm8XaB8wPLlt9D775uZEzgWeg74/iT3JJbffEvbdgB19Bau++XlVVKnIs9jV9HnwoSGHBQm4/hG+uijjymbn1B4Enrt113wNEYew7ifHcWNB+A7bqB5UsPc9/E2aSyGb8qxQ1NoLBXoLMDznnvvlcoZenxUqHHjJga2CKbLr7hKrDKcC4Tys88+C/zHJOMLM8dC44vM14JGBFHIysyjxYuW0CfcCLubIBaojLX+Rpn+g0bVk2k7ODYaWXR0Eh115Ex6mgWns/KJTOiuIzbnoIMO5euLoeQkn+TpdSwLLK15888N5BBMx59wEu255wi5vyeddFq78jQpOCMACce/ZfltbBnnsTib+gBwTQhBWbRwSZvF3FX68MOPJGgR98mEouA6vK2mngtTPlvoI2jWmWfJdqHpiiuv5ntn60aeiPKcOWcH/hueQuuxPWZHqbl5jJRJ+HnsOpzoyhVKV85UJBTYtm1m6snoMRNkSsj2zXGzdGxSG3JEmJIS0+n5558PnEO4GHVMeADobbetFJFoyzs9VxptK1/H5s0YccR1Gcc+onX/4z/+Py1cuFj+RjL5mah1g2nkt916m4RThJ+3Ad2M8eMn0uuvvyHbIgXFlPOC1cUWHzC/B/O3CZbUSSedKl0f07XquryxDRynudxNuuuuewI52WlD9vxh9ZmnM7CWpzkH/B4UiqVLL5D8jIXc8fExM2DWLNNAkfdvAZ8h5ov97r92o0WLlsrfSDgWtml/7aZ8bDzPc8+9wN20AuleQzQw6PDQQ2vkf0ih+QSvIQj+Z9N8ttLgbDaWU+8JEx4cp5xymmxnrsXsc+FFl/J9s3UOD6l4Ou20M+V/druegDJBoDJGtOGa6Oxe7Ez6XJiwphK6AE8/bYIibQEhwWTdY9CwkMYSeaN7o9CMMCXzObz55lty3NCE7lTojUMD6yjdc4+xmEylNCAIdEybMMEiNMI096z5MpscyfwebCiR6a477xZLIXi9+OSnKFsIh0w/QrpKSLYihjaUjlJopbVpMXclIU7BJ37wOoKYuVewBBFb9lagzIIN1jTg0GRGRIOTTpHsKKktF6QLLrxYGlZnDuX2wmSudcqUabTf5KnyHQ8A0FEKvXa7/wP3r6Zh3MAxU3/tusfkN/u/jpK5b8jL5GfTIYccwefJYtGBwPdMmEwemIh+yimny3b2/JEuChMmLh++fx1ZTJs3m/tjBPrXwK/eqbm5lesu3BId1YOdS58LE8BTH2Yzki10W7nhuN5992EyCmK6Xr1fUBASiNPJJ51Oy5Zdwg30AlqwYAldfPHl4p+xVgA+4aRHA164cCl/ni/bggsu+AsdftjR4owMzVuEqXWvEGEylf2KK64UfxKStRx+5ifVk08+xX38W+n666+nm25aLlNuYAXA8rLXDpGGAGLe3qafzZQZVDRUONvIEb8FP8O8eefSH/84gw477Cg69dRZnO9N9P77H8g2SLguYDXxTG70GAkNvYZI4JNB1/HVV1+TfWwewCbMlL/66r/L5NNJE6eIVTdt2iF0zvw/09q16wJbhR7fnAC6dcOiQqzOMMxcylBhgsChrpxwwomyDI5N6KbeeeddvO1sWbdo5sxjJCQFjd8ma0HZunbooUfQWXPnyXfbJcUgDLrS8CMddtiRdMQRR9N87kred98DbFmYxm3yMXkhYSUMCDhG8byuo8fCxBacEaYzZLvOhCk+PkOW/Vl2/sWmfi5aRvPOXsC9gReknqH+YX/U5VtuXcH1Y6Gpw4tMPV5y3gVct5dQUXEFJSbh/P+NhQkmdNnIqrARMGCtEzhKfT7Tz0ZofvCJ2luFhnzyaMTwJL7J8cIf/hAlQthuVO6lDVxJhtOee0a3bWvxGpXzEiZUDDhR8Yn0L36S/fWqa6i+oUVGkWQELyqWuzZx4iDH9JvQfOGXg7USDB4NPgHhrF+65HwqLinnfGLF0sIUHABraOiQaPGpnHnmnHbljfQzC10rn6+sohByHRaUPc7r+utulO1DLUqkjz/+RAYYsDoEjm1GCBH2kCRdNTQwLHiGeVpffvml7BO6/1NPPc0PoWR5ULQ/fnthAljm5uOPP2oTmMcee4IauCyHDsNKj3F8XCwiaI6dlJxBc+eew9f5S+B+mGPj+zfffC0DD1YkV96+ikaWVctDYCjnM2xYIkUxyBMjVy2j96JXNrwq25p7ELQWjzn2RBrM5e1VR3emMKHOmoEQvveBevmf//kHaUNI2M+e46RJ+9F/cfd3yJCEtm0B7tm//aicIV9M0NNOMwVvLZTQQsQIyLncfy+vqObGagovOjo14iZuD5GFD9HLEavAO47pNUppm8Rrtg0Smo+hvTAFGwISJmHut98BtMeew7nxpnC+ZrkVWHGhnzY//A3hujPg17H5IX36yWe0z96TaY/do8RyS5Vrs9cX/ETF3WOPKKqpbWyznkLzWfvIOhY/LNvaXhwwinfwQYfJdkih+6FsENqw5x7DA09bbwsXXUVYwZP3nSojXEGLFD6crTRhr0Dwa7sA0/bCFHp8JPi70B2DEKWm4tg4B0seWzHZ9If/GULHHnei3APUr8g8kK655joWlmiuayEOYJxP4JxwT9D483KL6e2335V9pJvEDxmku+9Gt97b8tuZwhTE1MkULgMIq53uhf1smzIBlnYSb8d1uC9wRJhMVwojCpdddoUUGiqN6ROHV5rvvvuO7r33Phmab2ps5cYXfDLHsuVlVvIzN3NHCrq3Ir87EiY0RqzHs8/EydxIh8q2XUe3mxUYID7IyzRoBKNuZQvsBxrTsjeL0vBuDRbgaYhRLJThD7yvccyb80Le++8/jY8V7D5aMFw/efIB9Mgja6W7ZBNWhCgtGcWCEN+9Jy0LLCzgG264SfaHox9WB9KiP59Hgwd5Ofs7EiZjeWIAAAutwaLs+BzyuY5kSWN94IHVsp+9JwDptdfe4PubKZZ8Z9eC/+2xxwjpJqP8rMghyahydqFnd27XCJMBDzKN/N4BcJOxdjEq9nncFbEp9KloR2BswujByxte4UK/kY48cqas44SGg6BKdKvwxOxWI/FgZwoTuj9IF150Cf3PboNDzrHrc8VTGjFKSKGV7IzTZ0sj6dn1csNiIUOYAVJohccyxV5PfHQV0PARwImgxQULFtGzzz5HM44+hsUkukfHx5IbB0w9SMRwyxaUjREmWBvB2KZQvIQJK1CYMjj88KO7UQb8v3Rj7WCdLSR73fhEOvXUMzgfFvhuXAuEJyMjlz74IGh58mNV5n3W1Y/m+x8e1wZUmLrGGWECqAiIZcHQKNZCDh0Ct08jCxo3FoYLTfDb4El+7jkLJdoZFR8VGWZ3zxrszhQmM90G1lJVZZ38vzuCBNA9KyurEuvIWjhIWFQvNi6Zkvgp77VfZ6DLiuDAL74I+nvQsD755FPKyy+REdPIfdIZlGksCxTuFYIkk5K9Hb2dgYdHXV2z+LXMsY0wIbYpMQnWb6TF620xISGAEOfUkcM5iGnoOLafu7I4tn1gIOHvmuoGvi+pAau7c3BMdDtXP/iQ7I98rCXbOnYf0yWN2EeFqWucEiZgJ67C1M7OyqOz557LN8yM/tgEXwQK2GBuEkZn0KBs+uWXn+nee+6jKVMPFkcuKkhPxGlnChMSVjhIiE8LdD27B6aRnHjiqbI/Vuq0ltcpJ58u3bKeiq8FFffm5bdKXhCHbVy+OFdEU7dvWO2PYZegify9K2TQo6xaHij22Eivv/66TKdpX8ZewmTKc+XKldxAO17FMQyuY7i/VuSR7P1FF8yXhS4YH1uml3jsH0aO+EeXt5WfEaatW7bSxIlTPQcRVJi6xjlhsqCRYW7QEL4hGXxjpk8/nJbfcpuYzJExKvZGBTGV1abVqx8SXwpurmlAaFz47Lji7cyuHNKK226Xa/PapyMg1rfeukL2N/nA8tpIoyr8bAFgTqEVDXtt3YDLdgh32c48wzZ2FrzAOSLSuGfnaPMN/Q3nBMezsS7sYvuw/n7/+8ESyBe63A2SCJPndKSOhQkBqxgp7drKMQ0doljBXf+gKJpjI5YNI4o9mQoFQbzppptlf+SDByfEafK+02h4VPs14lWYusZZYQqCeUtZMjyL0ShfdoGM5py/7EJZNcDeXJtsMB9ugKkkRsTwZDz55NOkcZsb7z1iZNnZwnTrLSu6/4RnMEEWx3z5ZROHY/NBfMqeew4T/w6uDQ23Z8TRf/9uNylTJIyK2caOGenwxXidT3uCAoSBDIz8YUoDQgVwHDSeYdxITdfVJ/5AxCzh/LlY5HrsNW2PMM2fv5jLIYb3C93ei86F6a233+7g2B3ToTBNUmHaXvqBMFlMxYeJjcoOB3dcXApVVdXR8cefTLetWNm2VrhJRgQsNv35z4vF9E5NxbyoPhQmtnwwHO21jxdo6AX5ZfTZZ5/L/sgH+b366usy1w4OW0xFMMzqEccfdxJdftkVUmGBbeyYYoMG4XU+QUwZJiSky8MDjRTrTxcWlUn08NQpB/K5nU5/ufRymRx67733y7sAv//OlCuSvUe2bHomTKaRzZ9/HgtTrApTBCpMuwquNOZG51EKdw2wPg5uGkIGsn0FMh0AS/HaqNwtgZsovhM8mjlhXhWWg+hPwoSRsFp/swRQIplrQiMI+tV2NJk8EUFuzrGzWByA8oMTGb6vvPxiOvyIo+hvf7uG1q17jD7//HMZNbVl7pWC1i0+g42tZ8Jk9jHChHsaur0XKkwqTLsIKzBYRQANCRWloXF0W5zK1q22ARjnKoIai4pGSvh+ZF4W14QJ+bS07CUvPbT5GBD9bEYpEU6BSru92PzsOT7I5TdiuFmaJfRc4JhO4QY0aHCs+Lew/DGEKDLhPNFAbd6I0Eb+Zj2goGCZ3831IG2XMJ2jFpMXKkyOAJGCkzVqeILckCVLTUyU6aIEY1Uw381MGfDOxzVhwgJsra37cD7owplQAcD1f6eldWsflXilUGFCw09KNkGtmNaCgFebbDfQik/H1tI2sfzgI7z8sstldYPQslFhUmEacMJkQSBgYqJPpnrgZZdIttEgvfDCS5SYnCGOWq/9XbSYmpvHh41goYJhygyWJX6RrweTWCN5KYDX/zrmRbnOv175N4lVChUmiD6GwJctu0iuA8kONljRtwldOaxThNAI+Jaw4B0mZR944CGyBheWPc7NKWwnDipMKkwDVpgMeWJpwEGOCmgatAlw/GnjRlkgDZXEa1/XhAnnWVPTJOfN2bTlgxUU42K5u8XnhNGu3gKNs/3Qv3krLBZEQ7LXA7YFumaYe3f55VcSZuo3NY6hvLwSFv9smYyMUVW8mhrTauAbRNlgqdoffsBr4INlo8KkwtTnwpTKlR/hAFg4H7Pok7lCdLfRd4eUVJ+sp/3kk+aFBKbicDeDwZwzEwDHNz9iP9eECQvq5eWVtq1QafNBZUagJmK+cE4GhBbsIHwfIq1J5I2XfQaXOzE+I1zXr7/8KhH3aNSYAwcBg8Mefj/ZT2KYwq9JGqgIU3iQowqTClOfCxO6XBkZmNNm/BcZGZg+4pOnrNf2PSWFbwzCCzDChBR6Y6YdcIg8vb32c02YIBZYoxxxP0g2HzTqkaWj+Hw7eEV0LwLrc9y4faThBSf9mhUBjj3mRPrD7wdJWIMR+vZiH0mcNNBavgbtyiGpMAXpU2HCE3XMmPGyqNgbr79Br7/2Or3J3ze8/IpMEEXl6U4F7wzMt8J8sCeeeFJuhqk4xjE7cZ/9TcXx2M81YQKonNdda9ZBgrWyhRsA0kEHYs3szsMfegMEW556ql22NTiKtmbNWrGQsGSL134dIfPV/E2B9d6DZazCpMLU58JU72+WmxiZZs48zhT4Dja2WLYksKjaN99+w7kaYZCux6+bqbERy4d6L7juojBBGGbOOE7237IlGP6wfPkKWWbXa5/uAEHDnDhEjuOtNXi3ndd2g7hxYOoHEq7DztWbP3+BNJyePkSwZhJWtYxcMkSFadcIE94rp8LkAXxLmKn+xhtm3WgUmh01wwRcWYA/tWdP4VBQSfE2XiyFihR6Q9/mCoj3nmGplfb75lBcvLcwodEYYULj7frcelOY4hPSqaBwJH311decQ1Bk0Z2rqq6TLqtYTdywujcB1YhSdHSCCN6sWXPYgmmkRKyAyBYYfEyhVhhWErjgQitMiJky14KwgbCXMHQJ8szj64+hG28MNujQMlZhstv3jjBdf337heKOOPwoFaaOwPSQK68MLvsJYcJNReFPO2C6CMv2dFGwD25mbW0ji4uNkzHD2kg33nCTHNtrX4DuX2lp+xUsseZ3jq+IEhIgaF2fV28KE6zHQSwOf7/mOsnDlJfJD4vnYTVChEh0t7ywHbpThUUj25bZxXIs69c/TZdddiUVFZcHfEZmezTAM86YLdshmNNabBddfCntOQgWm5kr1xU4LoSsqblV1lS35WKvRYWpl4WJHzLXhQgT9kdCORpL13vfvqTPhSmGG+7olnHtIpqRPv30M2ppHitLxWLUCRW6s0Zn/4eRICwdizWZ3nvvPclL8kVwIlcYVJp99t5PLIzIPKwVhHV9cnNLZBkMuz+eNDjHqVMPlgXJMrDipByz43PqVWHi4yC/urommXJj87MVDS+ahHBhKL47ZYUXPOB9bpjCg4R87MoNiEHCSzgh0HYfdPcmTtyftvJxUYZWmN56+x3+v6/tuKHHCcWeE+bUpaZmScwUktybAEgqTL0nTKjP+D/qBhL2s/tiQAjtBH5Yc98sXvnsWvpcmAAax9XXXCuFZQvdFh4Wh587d75sJy80ZNMTjQU3Lzi8bZbRgAPWrEvko9mz5oYvts+i9FtgPeaVK+9gUQqPaA5ihAlhBlh87dFHzat8Qs8JC5lheVZYc3jy47jw/8C6iGyYvStMhiEsPhdf/BfJx5aXNc+v4XLMzi6QFRjhw0N3zFwnIuLNYADKanf+fyr/D5YjkrGAMDXFnB98SZEWJcQaeWP9dSQIE5ZJQbr2uhvEYkM5hDcsA84DZbHbblHc7ayn558zo4sok8h7rsLUi8LE++IlCsf86QTZ/rffgqOpePgceuhR9Ps/DJZrQD3GPcc0pM4eMLuCvhcmrgQQmiyu8K+/Yd6Ei4Kz2ITXTZ+/7CJZb7q4uJIbGeZrZQpY46e0tJKmTD2QG+yl9M47xkpCilw3/L33P6CCwjJ5unueTxvoCkaHNAKbj2mIeP02fCvTDz5MQKXx17bwtYTPv9sZwgSBSErKbHv9k70+K04f8DXivXVVlX5KTEoTy3DoUPOGj4T4VFmbG0vA2BVCsZ/Jw1heb735ttwPxE5FHhsVd9nSC2Q700B+lU+kteselTXM8bp1CDZECo0G4M22tWzB4jXswWksZmoKunOmwZiyVWHqRWFi4vlBVF5W1VbuuM92f4gT3qByxBFH0YHTDpE33Ew/+AhKSGRLmR/wXvntChywmGBG5tNwRGhXN8i77ZFM4XtPdYAlhBCDDRs2CG+++abMtwpN9uaZ/c1NwLIofn8zP9nhJIY/pHMHMRpmZkYevf9e+JtEgFdatJAbh/hagnnsDGHCSwuwlnQZN6x33zVv6AgtL5tQ8bHEyOoH19CqVXfJu9Cee+7ZsLIKlpMRBVioCOFAd8vrqYkygdUE8UKy5RF6j3Bv0E3Ae/EA1ijHlJmfN5kldCFIaLz8QQsWLJRXPiGpMO0cYQJ4UGBbJPOQNXUFdTIy4cEuwc4djM7uCpwQJhQ+GhuGj0eNqqXnAkGESCg8gxkelwrdQQo++S3BxvLCiy9JF2Iom6vmbSRodJ0Lk/hDePuJk/YXpzCSfdoAVBAEF1pL5c4775YKEJrHzhAmU175FMUmN8Tp2YDlhBS8dhyno0m0tnKba0EjQoJwYzldjOJ4HxdlguMmyFpLX8voYLi4dXZ/iKxVZM5ryZILyJedL2KIZM5Zhan3hQmvrWIrOzGTHg28ZdgsOWPvm7G2bT2GFVXrb5KBETm+Z547Fyd8TCIQXBnS2TrBe7ySU7LovPOWto2IIYX7IoxIme/hv2Gb0KcA8liyZBmlpmVJ5HJ6Bh+Pj9WVKAXJk5n0U6ceJAv024TKZ548wUry6aefisMczne7P4SptXUCn1N4rNbKlat2QJhAoLz4mvB0g08IXSKb0DBCK14Q85tZIz2Y4AAv4S4eYpk6d+gbRykEuLFhjFhkNm3ZEnmscOx9gT9r0eKltNseUVReXtP2MgKbEMrRsTDFeb4C+9wFS1mYerqCZU1bcKdN773//nYJE96eHJn2m3xgh8KEbjYEIDS98cYbHQoTYsiwCGBkuuTSy/j4HT9IDLhn5rhYphoPUJtwS4x/0dwjK04z/3Qs13vk+28tTEFQ6dGwBw2OFmvgvPOWSSQ41uzpbsIM/Jde2kALFy6WN6niaYM8d8ShB8upqKhCJqiKQIWIn00/8ROwrm60OJ3tfhCm0aPH0Y8//CQVceNG83kjd3E6W4Stu9jywjXW1jZL6AVm9HuZ6JHpO+7SQZD2nTxVHNd4Qna3jLAdpvOkpmXLigF4LXZXCffwoYfW0F4TJvH5mpdJ4k0xX3/9tSmbnzbKJ1ZDgDiEN1AD7sPpp8+W7SAqmzaZ8px79gIaNAgWU/fOHwMA5eW19NVX3wSOvUk+X3nlVc4DMXY4dnceXhBLBDDeEMjnJxbaTSK2eDW618sI7FScb78NPzYGBOya6OH7mJivE086VbbbtPHntn2WYZBCLFxcd9c9gLjYdH6YJdKMGcfRM888J6PhXmnpsgukTqkwtSNPXgc+aM/hlJyUKV2Hk9mUxaJksDYefvgReZ30U0+up9WrH6YVK26XRom3iGCRODiH5ZXiXQxhdxfkgbwwIpaTUyQvhJwzZx4tXryMG+ZC+tOfjhf/FbaDY97uh++ZWQVUXVVPNdyVrGZqauqppLRCRshCj7FjICYpRc4PPqDJLDYLFiyWF0riVdd4j//tq+6Qt3nAujr00D9SSXGFWD5m+N5YQt55e4Pt0UXAQyQzM0+mxlzKT/BVfJxH1z1O69c/w0L0sBwT4tXcNEYahQnqM6OEGRkFMpG3uqaurYwqKmr4/1w2HqOmGN3LzSuRcqyu4n2q66Q88/NH9qg8cb0ZGfl8bORh7guABSfxWPIW3+7lh3Mq5rLEa5+qq5hAXr7swrC6YJE6kZkvVlP4sas9twdYmC83ryhse1w3YtBwfLNd1+eLe4btzShyutyTE084hRb++Tx+kC+hM06fJa8Ox4TxnrzBp7dxUJgiG0eePEFgeaAwBw+OladmLD/dMZoXH58pjmD4HvA/bIOXXsJx15030vYcY6HAz4Lj4akCYP1AGCIrlq0IMKMNaRQTmyKjHj0Vgu5hzg9PalglQ7i7iCdqVBTCGvCyApxztJQhyg6N0AwEeOXVHcz+ECjkCasFvkI8mc0LCZKkS4CywrvaIl9CCnEyZRIon8B9DT9GEGvNYJ9gmabwb1k9Lk/cq2AeqXIO6OKZOsjC2U1hwnExKBATg3MKnhfuu/c5GVGOPHbn121eyoG6E9wH1719PQHsg7mNiCPESKutx+iWou6gjHesXuwYDgpTZGF4PHH4N8QZYQUCPCXbXgveht22exWrZ3Ce4qPy+p8LeJQXNwJDyP+4gUf6PnYcU/4QH9wTVHysy25+5/sqDQh/h55j+/PtnJD8PP+/g7T5H/nce1w+fF7Yv9fL1ZaR1zWjLCJ/6w72OiN/t2Vr71Xk/3cNDnflFEX5d0WFSVEU51BhUhTFOVSYFEVxDhUmRVGcQ4VJURTnUGFSFMU5VJgURXEOFSZFUZxDhUlRFOdQYVIUxTlUmBRFcQ4VJkVRnEOFSVEU51BhUhTFOVSYFEVxDhUmRVGcQ4VJURTnUGFSFMU5VJgURXEOFSZFUZxDhUlRFOdQYVIUxTlUmBRFcQ4VJkVRnEOFSVEU51BhUhTFOVSYFEVxDhUmRVGcQ4VJURTnUGFSFMU5VJgURXEOFSZFUZxDhUlRFOdQYVIUxTlUmBRFcQ4VJkVRnEOFSVEU51BhUhTFOVSYFEVxDhUmRVGcQ4VJURTnUGFSFMU5VJgURXEOFSZFUZxDhUlRFOdQYVIUxTlUmBRFcQ4VJkVRnEOFSVEU51BhUhTFOVSYFEVxDhUmRVGcQ4VJURTnUGFSFMU5VJgURXEOFSZFUZxDhUlRFOdQYVIUxTlUmBRFcQ4VJkVRnEOFSVEU51BhUhTFOVSYFEVxDhUmRVGcQ4VJURTnUGFSFMU5VJgURXEOFSZFUZxDhUlRFOdQYVIUxTlUmBRFcQ4VJkVRnEOFSVEU51BhUhTFOVSYFEVxjFz6PwNRtGcymfxdAAAAAElFTkSuQmCC)\n",
        "\n",
        "Streamlit es una herramienta de código abierto diseñada para ayudar a los desarrolladores a crear aplicaciones web interactivas y visuales de manera muy rápida y sencilla, usando el lenguaje de programación Python.\n",
        "\n",
        "En términos simples, imagina que tienes un análisis de datos, un modelo de machine learning, o cualquier script en Python y quieres compartirlo con otros de manera visual e interactiva (sin necesidad de que ellos instalen Python o ejecuten el código). Streamlit te permite tomar ese código y transformarlo en una aplicación web funcional con solo unas pocas líneas.\n",
        "\n",
        "**¿Para qué sirve Streamlit?**\n",
        "\n",
        "- Crear interfaces visuales para proyectos en Python: Puedes mostrar gráficos, botones, formularios, tablas, etc.\n",
        "- Compartir proyectos interactivos: Los usuarios pueden interactuar con tus datos o modelos a través de la web sin saber programar.\n",
        "- Prototipar rápido: En lugar de construir toda una página web desde cero, Streamlit facilita la creación de prototipos de manera rápida.\n",
        "\n",
        "Las demos utilizadas en este Notebook fueron extraidas de los tutoriales para crear una \"Multipage App\" via Streamlit, estas pueden ser consultadas en el enlace relacionado para la documentación.\n",
        "Para mayor detalle en el uso de streamlit, podemos recurrir a su propia documentación, con ejemplos y otros detalles: https://docs.streamlit.io/get-started"
      ],
      "metadata": {
        "id": "6OmE8HsUA2W_"
      }
    },
    {
      "cell_type": "markdown",
      "source": [
        "# **Instalación de librerías**"
      ],
      "metadata": {
        "id": "Elnq10QfBNM3"
      }
    },
    {
      "cell_type": "code",
      "execution_count": null,
      "metadata": {
        "id": "rkQn_3iV7Ck-",
        "colab": {
          "base_uri": "https://localhost:8080/"
        },
        "outputId": "5f92583e-6425-4e0d-a43f-4c476487d37b"
      },
      "outputs": [
        {
          "output_type": "stream",
          "name": "stdout",
          "text": [
            "\u001b[2K     \u001b[90m━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\u001b[0m \u001b[32m44.3/44.3 kB\u001b[0m \u001b[31m1.2 MB/s\u001b[0m eta \u001b[36m0:00:00\u001b[0m\n",
            "\u001b[2K   \u001b[90m━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\u001b[0m \u001b[32m9.1/9.1 MB\u001b[0m \u001b[31m39.9 MB/s\u001b[0m eta \u001b[36m0:00:00\u001b[0m\n",
            "\u001b[2K   \u001b[90m━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\u001b[0m \u001b[32m6.9/6.9 MB\u001b[0m \u001b[31m28.3 MB/s\u001b[0m eta \u001b[36m0:00:00\u001b[0m\n",
            "\u001b[2K   \u001b[90m━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\u001b[0m \u001b[32m79.1/79.1 kB\u001b[0m \u001b[31m3.1 MB/s\u001b[0m eta \u001b[36m0:00:00\u001b[0m\n",
            "\u001b[?25h"
          ]
        }
      ],
      "source": [
        "#instalación de librerías\n",
        "!pip install streamlit -q"
      ]
    },
    {
      "cell_type": "markdown",
      "source": [
        "##Crear carpeta pages para trabajar Multiapp en Streamlit"
      ],
      "metadata": {
        "id": "uFYn5Ura7jxG"
      }
    },
    {
      "cell_type": "code",
      "source": [
        "!mkdir pages"
      ],
      "metadata": {
        "id": "j_yjXe027jRG"
      },
      "execution_count": null,
      "outputs": []
    },
    {
      "cell_type": "markdown",
      "source": [
        "# **Página principal**"
      ],
      "metadata": {
        "id": "w7teY1GZ80jN"
      }
    },
    {
      "cell_type": "code",
      "source": [
        "%%writefile 0_👋_Hello.py\n",
        "\n",
        "import streamlit as st\n",
        "\n",
        "st.set_page_config(\n",
        "    page_title=\"Bienvenida\",\n",
        "    page_icon=\"👋\",\n",
        ")\n",
        "\n",
        "st.write(\"# Bienvenido a Streamlit! 👋\")\n",
        "\n",
        "st.sidebar.success(\"Seleccciona una demo a explorar.\")\n",
        "\n",
        "st.markdown(\n",
        "    \"\"\"\n",
        "    Streamlit es una aplicación de código abierto creado específicamente para\n",
        "    Proyectos de Machine Learning y Data Science.\n",
        "    **👈 Seleccione una demostración de la barra lateral** para ver algunos ejemplos\n",
        "    ¡De lo que Streamlit puede hacer!\n",
        "    ### ¿Quieres saber más?\n",
        "    - Consulta [streamlit.io] (https://streamlit.io)\n",
        "    - Revisa la [documentación](https://docs.streamlit.io)\n",
        "\"\"\"\n",
        ")"
      ],
      "metadata": {
        "id": "lkE-F8Jy87pW",
        "colab": {
          "base_uri": "https://localhost:8080/"
        },
        "outputId": "7798f973-1a89-4d1f-e249-4ca7080dd651"
      },
      "execution_count": null,
      "outputs": [
        {
          "output_type": "stream",
          "name": "stdout",
          "text": [
            "Writing 0_👋_Hello.py\n"
          ]
        }
      ]
    },
    {
      "cell_type": "markdown",
      "source": [
        "# **Páginas**"
      ],
      "metadata": {
        "id": "pvl_iVLa8EAs"
      }
    },
    {
      "cell_type": "markdown",
      "source": [
        "Cada pagina se debe enviar al directorio \\pages"
      ],
      "metadata": {
        "id": "N1zbc14f8pg3"
      }
    },
    {
      "cell_type": "markdown",
      "source": [
        "## **1. Plotting Demo**"
      ],
      "metadata": {
        "id": "nYrp3adz8lwb"
      }
    },
    {
      "cell_type": "code",
      "source": [
        "%%writefile 1_📈_Plotting_Demo.py\n",
        "\n",
        "import streamlit as st\n",
        "import time\n",
        "import numpy as np\n",
        "\n",
        "st.set_page_config(page_title=\"Plotting Demo\", page_icon=\"📈\")\n",
        "\n",
        "st.markdown(\"# Plotting Demo\")\n",
        "st.sidebar.header(\"Plotting Demo\")\n",
        "st.write(\n",
        "    \"\"\"Esta demostración ilustra una combinación de trazado y animación con\n",
        "Iluminado. Estamos generando un montón de números aleatorios en un bucle durante aproximadamente\n",
        "5 segundos. ¡Disfruta!\"\"\"\n",
        ")\n",
        "\n",
        "progress_bar = st.sidebar.progress(0)\n",
        "status_text = st.sidebar.empty()\n",
        "last_rows = np.random.randn(1, 1)\n",
        "chart = st.line_chart(last_rows)\n",
        "\n",
        "for i in range(1, 101):\n",
        "    new_rows = last_rows[-1, :] + np.random.randn(5, 1).cumsum(axis=0)\n",
        "    status_text.text(\"%i%% Complete\" % i)\n",
        "    chart.add_rows(new_rows)\n",
        "    progress_bar.progress(i)\n",
        "    last_rows = new_rows\n",
        "    time.sleep(0.05)\n",
        "\n",
        "progress_bar.empty()\n",
        "\n",
        "st.button(\"Re-run\")"
      ],
      "metadata": {
        "id": "38sFD2uy7HUh",
        "colab": {
          "base_uri": "https://localhost:8080/"
        },
        "outputId": "f13f88c2-6925-4279-ee40-5d30f77df040"
      },
      "execution_count": null,
      "outputs": [
        {
          "output_type": "stream",
          "name": "stdout",
          "text": [
            "Writing 1_📈_Plotting_Demo.py\n"
          ]
        }
      ]
    },
    {
      "cell_type": "code",
      "source": [
        "!mv 1_📈_Plotting_Demo.py pages/"
      ],
      "metadata": {
        "id": "xnAQCqpb9sYn"
      },
      "execution_count": null,
      "outputs": []
    },
    {
      "cell_type": "markdown",
      "source": [
        "## **2. Mapping Demo**"
      ],
      "metadata": {
        "id": "SiQbBkwu9cW-"
      }
    },
    {
      "cell_type": "code",
      "source": [
        "%%writefile 2_🌍_Mapping_Demo.py\n",
        "\n",
        "import streamlit as st\n",
        "import pandas as pd\n",
        "import pydeck as pdk\n",
        "from urllib.error import URLError\n",
        "\n",
        "st.set_page_config(page_title=\"Mapping Demo\", page_icon=\"🌍\")\n",
        "\n",
        "st.markdown(\"# Mapping Demo\")\n",
        "st.sidebar.header(\"Mapping Demo\")\n",
        "st.write(\n",
        "    \"\"\"Esta demo muestra como usar\n",
        "[`st.pydeck_chart`](https://docs.streamlit.io/develop/api-reference/charts/st.pydeck_chart)\n",
        "para visualizar información geoespacial.\"\"\"\n",
        ")\n",
        "\n",
        "\n",
        "@st.cache_data\n",
        "def from_data_file(filename):\n",
        "    url = (\n",
        "        \"http://raw.githubusercontent.com/streamlit/\"\n",
        "        \"example-data/master/hello/v1/%s\" % filename\n",
        "    )\n",
        "    return pd.read_json(url)\n",
        "\n",
        "\n",
        "try:\n",
        "    ALL_LAYERS = {\n",
        "        \"Bike Rentals\": pdk.Layer(\n",
        "            \"HexagonLayer\",\n",
        "            data=from_data_file(\"bike_rental_stats.json\"),\n",
        "            get_position=[\"lon\", \"lat\"],\n",
        "            radius=200,\n",
        "            elevation_scale=4,\n",
        "            elevation_range=[0, 1000],\n",
        "            extruded=True,\n",
        "        ),\n",
        "        \"Bart Stop Exits\": pdk.Layer(\n",
        "            \"ScatterplotLayer\",\n",
        "            data=from_data_file(\"bart_stop_stats.json\"),\n",
        "            get_position=[\"lon\", \"lat\"],\n",
        "            get_color=[200, 30, 0, 160],\n",
        "            get_radius=\"[exits]\",\n",
        "            radius_scale=0.05,\n",
        "        ),\n",
        "        \"Bart Stop Names\": pdk.Layer(\n",
        "            \"TextLayer\",\n",
        "            data=from_data_file(\"bart_stop_stats.json\"),\n",
        "            get_position=[\"lon\", \"lat\"],\n",
        "            get_text=\"name\",\n",
        "            get_color=[0, 0, 0, 200],\n",
        "            get_size=15,\n",
        "            get_alignment_baseline=\"'bottom'\",\n",
        "        ),\n",
        "        \"Outbound Flow\": pdk.Layer(\n",
        "            \"ArcLayer\",\n",
        "            data=from_data_file(\"bart_path_stats.json\"),\n",
        "            get_source_position=[\"lon\", \"lat\"],\n",
        "            get_target_position=[\"lon2\", \"lat2\"],\n",
        "            get_source_color=[200, 30, 0, 160],\n",
        "            get_target_color=[200, 30, 0, 160],\n",
        "            auto_highlight=True,\n",
        "            width_scale=0.0001,\n",
        "            get_width=\"outbound\",\n",
        "            width_min_pixels=3,\n",
        "            width_max_pixels=30,\n",
        "        ),\n",
        "    }\n",
        "    st.sidebar.markdown(\"### Capas de mapa\")\n",
        "    selected_layers = [\n",
        "        layer\n",
        "        for layer_name, layer in ALL_LAYERS.items()\n",
        "        if st.sidebar.checkbox(layer_name, True)\n",
        "    ]\n",
        "    if selected_layers:\n",
        "        st.pydeck_chart(\n",
        "            pdk.Deck(\n",
        "                map_style=\"mapbox://styles/mapbox/light-v9\",\n",
        "                initial_view_state={\n",
        "                    \"latitude\": 37.76,\n",
        "                    \"longitude\": -122.4,\n",
        "                    \"zoom\": 11,\n",
        "                    \"pitch\": 50,\n",
        "                },\n",
        "                layers=selected_layers,\n",
        "            )\n",
        "        )\n",
        "    else:\n",
        "        st.error(\"Por favor elija al menos una capa arriba.\")\n",
        "except URLError as e:\n",
        "    st.error(\n",
        "        \"\"\"\n",
        "        **Esta demo requiere conexión a internet.**\n",
        "        Connection error: %s\n",
        "    \"\"\"\n",
        "        % e.reason\n",
        "    )"
      ],
      "metadata": {
        "id": "pSa19dku9hCw",
        "colab": {
          "base_uri": "https://localhost:8080/"
        },
        "outputId": "e5dde40c-752f-4f00-aea0-83c8656cfa74"
      },
      "execution_count": null,
      "outputs": [
        {
          "output_type": "stream",
          "name": "stdout",
          "text": [
            "Writing 2_🌍_Mapping_Demo.py\n"
          ]
        }
      ]
    },
    {
      "cell_type": "code",
      "source": [
        "!mv 2_🌍_Mapping_Demo.py pages/"
      ],
      "metadata": {
        "id": "ZwNJFSzI-d2N"
      },
      "execution_count": null,
      "outputs": []
    },
    {
      "cell_type": "markdown",
      "source": [
        "## **3. DataFrame Demo**"
      ],
      "metadata": {
        "id": "BnF4mSda-rgN"
      }
    },
    {
      "cell_type": "code",
      "source": [
        "%%writefile 3_📊_DataFrame_Demo.py\n",
        "\n",
        "import streamlit as st\n",
        "import pandas as pd\n",
        "import altair as alt\n",
        "from urllib.error import URLError\n",
        "\n",
        "st.set_page_config(page_title=\"DataFrame Demo\", page_icon=\"📊\")\n",
        "\n",
        "st.markdown(\"# DataFrame Demo\")\n",
        "st.sidebar.header(\"DataFrame Demo\")\n",
        "st.write(\n",
        "    \"\"\"Esta demo muestra como usar `st.write` para visualizar Pandas DataFrames.\n",
        "(Datos cortesia de [UN Data Explorer](http://data.un.org/Explorer.aspx).)\"\"\"\n",
        ")\n",
        "\n",
        "\n",
        "@st.cache_data\n",
        "def get_UN_data():\n",
        "    AWS_BUCKET_URL = \"http://streamlit-demo-data.s3-us-west-2.amazonaws.com\"\n",
        "    df = pd.read_csv(AWS_BUCKET_URL + \"/agri.csv.gz\")\n",
        "    return df.set_index(\"Region\")\n",
        "\n",
        "\n",
        "try:\n",
        "    df = get_UN_data()\n",
        "    countries = st.multiselect(\n",
        "        \"Seleccione los paises\", list(df.index), [\"China\", \"United States of America\"]\n",
        "    )\n",
        "    if not countries:\n",
        "        st.error(\"Por favor seleccione al menos un pais.\")\n",
        "    else:\n",
        "        data = df.loc[countries]\n",
        "        data /= 1000000.0\n",
        "        st.write(\"### Producción Agricola Bruta ($B)\", data.sort_index())\n",
        "\n",
        "        data = data.T.reset_index()\n",
        "        data = pd.melt(data, id_vars=[\"index\"]).rename(\n",
        "            columns={\"index\": \"year\", \"value\": \"Gross Agricultural Product ($B)\"}\n",
        "        )\n",
        "        chart = (\n",
        "            alt.Chart(data)\n",
        "            .mark_area(opacity=0.3)\n",
        "            .encode(\n",
        "                x=\"year:T\",\n",
        "                y=alt.Y(\"Gross Agricultural Product ($B):Q\", stack=None),\n",
        "                color=\"Region:N\",\n",
        "            )\n",
        "        )\n",
        "        st.altair_chart(chart, use_container_width=True)\n",
        "except URLError as e:\n",
        "    st.error(\n",
        "        \"\"\"\n",
        "        **Esta demo requiere conexión a internet.**\n",
        "        Connection error: %s\n",
        "    \"\"\"\n",
        "        % e.reason\n",
        "    )"
      ],
      "metadata": {
        "id": "Oqk0FZV5-st_",
        "colab": {
          "base_uri": "https://localhost:8080/"
        },
        "outputId": "ca643489-f432-4bd0-e1f3-9bef678e16c8"
      },
      "execution_count": null,
      "outputs": [
        {
          "output_type": "stream",
          "name": "stdout",
          "text": [
            "Writing 3_📊_DataFrame_Demo.py\n"
          ]
        }
      ]
    },
    {
      "cell_type": "code",
      "source": [
        "!mv 3_📊_DataFrame_Demo.py pages/"
      ],
      "metadata": {
        "id": "EPbGLQnx-21f"
      },
      "execution_count": null,
      "outputs": []
    },
    {
      "cell_type": "markdown",
      "source": [
        "# **Inicialización del Dashboard a partir de túnel local**\n",
        "\n",
        "1. **Reemplazar nombre de archivo**: Reemplaza el nombre del archivo como se indica en el comentario de la linea 6 de la celda de codigo\n",
        "\n",
        "2. **Accede al enlace provisional**: Una vez que la aplicación esté corriendo, LocalTunnel generará un enlace temporal. Haz clic o copia ese enlace para acceder a tu aplicación en el navegador (cada vez que corras la celda, el link podrá ser diferente).\n",
        "\n",
        "**Nota:**\n",
        "Para finalizar la ejecución del Dashboard ejecuta la ultima celda de codigo y sigue las instrucciones."
      ],
      "metadata": {
        "id": "QOJ7v8TmAJ82"
      }
    },
    {
      "cell_type": "code",
      "source": [
        "!wget https://github.com/cloudflare/cloudflared/releases/latest/download/cloudflared-linux-amd64\n",
        "!chmod +x cloudflared-linux-amd64\n",
        "!mv cloudflared-linux-amd64 /usr/local/bin/cloudflared\n",
        "\n",
        "#Ejecutar Streamlit\n",
        "!streamlit run 0_👋_Hello.py &>/content/logs.txt & #Cambiar 0_👋_Hello.py por el nombre de tu archivo principal\n",
        "\n",
        "#Exponer el puerto 8501 con Cloudflare Tunnel\n",
        "!cloudflared tunnel --url http://localhost:8501 > /content/cloudflared.log 2>&1 &\n",
        "\n",
        "#Leer la URL pública generada por Cloudflare\n",
        "import time\n",
        "time.sleep(5)  # Esperar que se genere la URL\n",
        "\n",
        "import re\n",
        "found_context = False  # Indicador para saber si estamos en la sección correcta\n",
        "\n",
        "with open('/content/cloudflared.log') as f:\n",
        "    for line in f:\n",
        "        #Detecta el inicio del contexto que nos interesa\n",
        "        if \"Your quick Tunnel has been created\" in line:\n",
        "            found_context = True\n",
        "\n",
        "        #Busca una URL si ya se encontró el contexto relevante\n",
        "        if found_context:\n",
        "            match = re.search(r'https?://\\S+', line)\n",
        "            if match:\n",
        "                url = match.group(0)  #Extrae la URL encontrada\n",
        "                print(f'Tu aplicación está disponible en: {url}')\n",
        "                break  #Termina el bucle después de encontrar la URL"
      ],
      "metadata": {
        "colab": {
          "base_uri": "https://localhost:8080/"
        },
        "id": "rOM4aEY4P62M",
        "outputId": "cdefbe9e-b929-41ce-bbda-56d2a52ca9c2"
      },
      "execution_count": null,
      "outputs": [
        {
          "output_type": "stream",
          "name": "stdout",
          "text": [
            "--2025-01-21 15:24:13--  https://github.com/cloudflare/cloudflared/releases/latest/download/cloudflared-linux-amd64\n",
            "Resolving github.com (github.com)... 140.82.113.4\n",
            "Connecting to github.com (github.com)|140.82.113.4|:443... connected.\n",
            "HTTP request sent, awaiting response... 302 Found\n",
            "Location: https://github.com/cloudflare/cloudflared/releases/download/2025.1.0/cloudflared-linux-amd64 [following]\n",
            "--2025-01-21 15:24:13--  https://github.com/cloudflare/cloudflared/releases/download/2025.1.0/cloudflared-linux-amd64\n",
            "Reusing existing connection to github.com:443.\n",
            "HTTP request sent, awaiting response... 302 Found\n",
            "Location: https://objects.githubusercontent.com/github-production-release-asset-2e65be/106867604/4d2d8552-523a-4e77-b9e2-223b16b06c83?X-Amz-Algorithm=AWS4-HMAC-SHA256&X-Amz-Credential=releaseassetproduction%2F20250121%2Fus-east-1%2Fs3%2Faws4_request&X-Amz-Date=20250121T152320Z&X-Amz-Expires=300&X-Amz-Signature=f46fe6c6a1fd3997a61e1e3e77d5f9c74ca22239bd2fc31de693f4639716f0dd&X-Amz-SignedHeaders=host&response-content-disposition=attachment%3B%20filename%3Dcloudflared-linux-amd64&response-content-type=application%2Foctet-stream [following]\n",
            "--2025-01-21 15:24:13--  https://objects.githubusercontent.com/github-production-release-asset-2e65be/106867604/4d2d8552-523a-4e77-b9e2-223b16b06c83?X-Amz-Algorithm=AWS4-HMAC-SHA256&X-Amz-Credential=releaseassetproduction%2F20250121%2Fus-east-1%2Fs3%2Faws4_request&X-Amz-Date=20250121T152320Z&X-Amz-Expires=300&X-Amz-Signature=f46fe6c6a1fd3997a61e1e3e77d5f9c74ca22239bd2fc31de693f4639716f0dd&X-Amz-SignedHeaders=host&response-content-disposition=attachment%3B%20filename%3Dcloudflared-linux-amd64&response-content-type=application%2Foctet-stream\n",
            "Resolving objects.githubusercontent.com (objects.githubusercontent.com)... 185.199.109.133, 185.199.110.133, 185.199.111.133, ...\n",
            "Connecting to objects.githubusercontent.com (objects.githubusercontent.com)|185.199.109.133|:443... connected.\n",
            "HTTP request sent, awaiting response... 200 OK\n",
            "Length: 37739514 (36M) [application/octet-stream]\n",
            "Saving to: ‘cloudflared-linux-amd64’\n",
            "\n",
            "cloudflared-linux-a 100%[===================>]  35.99M   124MB/s    in 0.3s    \n",
            "\n",
            "2025-01-21 15:24:14 (124 MB/s) - ‘cloudflared-linux-amd64’ saved [37739514/37739514]\n",
            "\n",
            "Tu aplicación está disponible en: https://frames-ac-brutal-profiles.trycloudflare.com\n"
          ]
        }
      ]
    },
    {
      "cell_type": "markdown",
      "source": [
        "# **Finalización de ejecución del Dashboard**"
      ],
      "metadata": {
        "id": "uT6Mjt2Ke6At"
      }
    },
    {
      "cell_type": "code",
      "source": [
        "import os\n",
        "\n",
        "res = input(\"Digite (1) para finalizar la ejecución del Dashboard: \")\n",
        "\n",
        "if res.upper() == \"1\":\n",
        "    os.system(\"pkill streamlit\")  # Termina el proceso de Streamlit\n",
        "    print(\"El proceso de Streamlit ha sido finalizado.\")\n"
      ],
      "metadata": {
        "id": "BTtojSodRulL",
        "colab": {
          "base_uri": "https://localhost:8080/"
        },
        "outputId": "984f8c77-9df8-46e6-c4e1-f510db1d67f6"
      },
      "execution_count": null,
      "outputs": [
        {
          "output_type": "stream",
          "name": "stdout",
          "text": [
            "Digite (1) para finalizar la ejecución del Dashboard: 1\n",
            "El proceso de Streamlit ha sido finalizado.\n"
          ]
        }
      ]
    }
  ]
}